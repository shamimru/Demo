/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;

@ManagedBean
@RequestScoped
public class Student {

    int userid;
    String password;

    public Student() {
    }

    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String login() {
        String ret = "fail.xhtml";
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stdb", "root", "nclc123456");

            PreparedStatement ps = con.prepareStatement("select * from student where userid=?");
            ps.setInt(1, this.userid);
            rs = ps.executeQuery();
            while (rs.next()) {
                ret = "success.xhtml";
               
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        
        return ret;
    }
}
