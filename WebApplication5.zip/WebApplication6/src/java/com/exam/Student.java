/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Student
 */
@ManagedBean
@SessionScoped
public class Student {
   
    int userid;
    String password;

    public Student() {
    }

    public Student(int userid, String password) {
        this.userid = userid;
        this.password = password;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String login() {

        String ret = "f.xhtml";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stdb", "root", "nclc123456");
            PreparedStatement ps = con.prepareStatement("SELECT * FROM student WHERE userid=?");
            ps.setInt(1, this.userid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ret = "s.xhtml";   
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }

        return ret;
    }
}
