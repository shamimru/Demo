package Question_2;

public class Test {
    public static void main(String [] args){

        Account acc1=new Account(101,1000);
        Account acc2=new Account(102,1000);


//        System.out.println(acc1.getBalance());

//        acc1.deposit(1000);
//        System.out.println(acc1.getBalance());

//        System.out.println(acc1.withdraw(500));

        System.out.println(acc1.transfer(acc2,500));

        System.out.println("Account 2 "+ acc2.getBalance());
        System.out.println("Account 1 "+acc1.getBalance());
    }
}
