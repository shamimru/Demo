package Question_2;

public class Bank {
    public double deposit(double amt){
        return amt;
    }

    public  double transfer(Object acc, double amt){

        return  amt;
    }

    public  double withdraw(double amt){
        return  amt;
    }
}
