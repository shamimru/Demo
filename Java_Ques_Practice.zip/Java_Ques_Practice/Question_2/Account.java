package Question_2;

public class Account extends Bank{
    int accNo;
    double balance;

    public Account() {
    }

    public Account(int accNo, double balance) {
        this.accNo = accNo;
        this.balance = balance;
    }

    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accNo=" + accNo +
                ", balance=" + balance +
                '}';
    }


    @Override
    public double deposit(double amt) {
        return this.balance=this.balance + amt;
    }


    public double transfer(Account acc, double amt) {
        if( this.balance < amt){
            System.out.println("Insufficient Balance to Transfer");
            return this.balance;
//            System.exit(1);
        }else {
            acc.balance = acc.balance + amt;
            this.balance = this.balance - amt;
        }
        return this.balance;
    }

    @Override
    public double withdraw(double amt) {
        this.balance = this.balance - amt;
        return this.balance;
    }
}
