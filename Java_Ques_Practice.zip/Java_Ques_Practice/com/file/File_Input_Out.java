package com.file;

import java.io.*;
import java.util.ArrayList;

public class File_Input_Out implements Serializable {


    public static void main(String [] args){
        Student st1=new Student(101,"shamim",20000);
        Student st2=new Student(102,"Ahamed",3000);
        Student st3=new Student(103,"Ali",45000);

        ArrayList<Student> lists= new ArrayList<>();
        lists.add(st1);
        lists.add(st2);
        lists.add(st3);


        try{
            ObjectOutputStream obj=new ObjectOutputStream(new FileOutputStream("abc.dat"));
            obj.writeObject(lists);
            obj.flush();
            obj.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        try{
            ObjectInputStream obj_2=new ObjectInputStream(new FileInputStream("abc.dat"));
//            try{
                System.out.println(obj_2.readObject()+"\n");
                System.out.println();
//            }catch (Exception e){
//                System.out.println(e);
//            }

//            for(Student list: lists){
//                int id=(Student) obj_2.readInt();
//                String name=obj_2.readUTF();
//                double balance=obj_2.readDouble();
//                System.out.println("Your id is -> "+obj_2.id+" name is -> "+obj_2.readUTF(obj_2.name)+" and Balance is -> "+balance);
            obj_2.close();
        }catch (ClassNotFoundException e){
            System.out.println(e);
        }
        catch (IOException e){
            System.out.println(e);
        }
    }
}
