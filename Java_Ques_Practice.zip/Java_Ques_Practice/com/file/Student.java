package com.file;

import java.io.Serializable;

public class Student implements Serializable {
    int id;
    String name;
    double balance;

    public Student() {
    }

    public Student(int id, String name, double balance) {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return
                "id is => " + id +
                " Your name is => " + name  +
                " And Balance is => " + balance + "\n";
    }
}
