import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        Teacher t1=new Teacher("shamim",101,"abc@gmail.com",56,"kuntiar-char");
        Teacher t2=new Teacher("Ahamed",102,"def@gmail.com",54,"Kushtia");


        ArrayList<Teacher> lists=new ArrayList<>();
        lists.add(t1);
        lists.add(t2);

        for (Teacher list : lists) {
            System.out.println(list.showAddress());
        }
    }
}