public class Teacher extends Person {
    int id;
    String email;
    int round;
    String address;


    public Teacher() {
    }

    public Teacher(int id) {
        this.id = id;
    }

    public Teacher(String name, int id, String email, int round, String address) {
        super(name);
        this.id = id;
        this.email = email;
        this.round = round;
        this.address = address;
    }


//    Teacher(int id,String email,int round, String address){
//        this.id=id;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", round=" + round +
                ", address='" + address + '\'' +
                '}';
    }

    public String showAddress(){
        return  "Your address is "+this.address;
    }
}
